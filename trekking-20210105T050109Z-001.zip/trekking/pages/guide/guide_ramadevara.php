<!DOCTYPE html>
<html>
<head>
<title>Guides of Ramadevara Katte</title>
<script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=uIrcORyH_0eAcRqUXzPyKKZF8E413ksryZsCiniJV4Pabc7MQF7ddcQ1W8KEDrxlky2uJafMQCKiPL3AE5sjlZgkOUFw6l5MD95j7ZcQnUtoGp8Pq7yHSyqejSgNCFlWClCf1kTtZV3AwCykmeBY37ziytWj4NlCWd4v-B4q1PPStGcwJKU9Xf6MmafSIoUng5rky1CZUe1iMRrQ362JL0DHTjqI8w8hlh4tkYZ_N0Cb_n_3FZJ4kGyrKslWXolYSLqGXvkvqRe1XQ9k8qlMF_7Evb2z1GpuRBhiWBnfO6xpTtnadxoMySu_bagkj47fPfaKWw6DMoV0Xw5VUYeDgB2iCtYMc0GIcIerlIDzzE_Tn1WDpWEqFJOYuZXsXE4MRRBfnLr1YCGtRAC21Sr3b08Zw7fRvrG_wkzZ3xesW7ZhYCqEdPrZ5H0PnUT8vISHU71yMwG5f47NYAhcTMbsETJhIRu9FxdVm-9ernw0OJai3ZoRspdt-pwWs4mX3HRZVDQfESTlTxep4PWNN7yT47YD_FFfynU9y3i7sN9_KGfxw7BYodHLdKGsYCKEsF1949xUQAa2iLvspzise4X7kUgaK5DfuYMWr3Jfj-D7mZ65rwqrdRNOAZ_cGaFlQ7zAMa7_bVg8JCYXZ2UYj3rx6WEEXc3TjUmepOwVvTqwx_c9PHdSeHdkoH7Bk6kL8gP2paGRPzhYktcIywaUwKmZHps3efehR0wqy3Ttt4N2te1QOaVofUrLXe-ftHbW4-8hb_InM0UDkNvZqAC-HdcLlDMhl6yDSL_-PCH_UZCun98rOzKGs6NCJBtOV54SmoOFGGqU6YevWyw3XGetRMv8Bn3fm0q09DB81m-Sjfer5SXo3tSav9RxmkM0ktS0ZhmNDbjTaMymJSHIALkUzzReVg82l2lfPjn9tgPIN3fgN3brDqcZ4SUzc9RW5Xwebp4FtL_xTn0hsdeACseaJKGHula3KX87m0mb8M4d51YhYihyIyprYsmzkTlk8kKpldxA9MepQQDHxdzY-xO_npTpMdWr6qqY_5Dah_ATxy0lqnlfTZFA2UiYlFcTrryGG92w6X0Bj9i-YVFOkh7oSSsh2k93RVPQ7FgmHt7HweQhwdRDu9-1OqrYGEbFjcapfyksPp37nNRlQzaW7-dK0J1ezxuvJ7OowmP5FoJljvgTFxnt7blDprRbdTCXu5mPSzpYJXUSqcbGS7F--rV7stBQKg" nonce="3ed4bc7600aae7b371fec81c01c04da6" charset="UTF-8"></script>
<link type="text/css" rel="stylesheet" href="generalguide.css" />
</head>
<body onload="myFunction()">

<header class="test">
    
        <nav class="navbar">
            <ul class="navigation">
                <li><a href="../index.html">Home</a></li>
                <li><a href="../aboutus.html"> About us</a></li>
                <li><a href="../contactus.html">Contact us</a></li>
                <li><a href="../feedback.html">Feedback</a></li>
            </ul>
        </nav>



<hr>

<table id="para">
<tr>
<th>Guide Name</th>
<th>Language</th>
<th>Phone Number</th>
</tr>

<?php
$conn = mysqli_connect("localhost:3307", "root", "", "tourism_db");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT gname, lang, phone  FROM guide where pid=9";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["gname"]. "</td><td>" . $row["lang"]."</td><td>" . $row["phone"] .   "</td></tr>";
"<hr><hr>";
 
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

<hr><hr>

<br><br>

<a href="../contactus.html" button class="btn">Any queries? Contact us</button></a>


 
</header>
</body>
</html>