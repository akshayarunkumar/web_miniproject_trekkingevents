<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
<script type="text/javascript" src="https://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=uIrcORyH_0eAcRqUXzPyKKZF8E413ksryZsCiniJV4Pabc7MQF7ddcQ1W8KEDrxlky2uJafMQCKiPL3AE5sjlZgkOUFw6l5MD95j7ZcQnUtoGp8Pq7yHSyqejSgNCFlWClCf1kTtZV3AwCykmeBY37ziytWj4NlCWd4v-B4q1PPStGcwJKU9Xf6MmafSIoUng5rky1CZUe1iMRrQ362JL0DHTjqI8w8hlh4tkYZ_N0Cb_n_3FZJ4kGyrKslWXolYSLqGXvkvqRe1XQ9k8qlMF_7Evb2z1GpuRBhiWBnfO6xpTtnadxoMySu_bagkj47fPfaKWw6DMoV0Xw5VUYeDgB2iCtYMc0GIcIerlIDzzE_Tn1WDpWEqFJOYuZXsXE4MRRBfnLr1YCGtRAC21Sr3b08Zw7fRvrG_wkzZ3xesW7ZhYCqEdPrZ5H0PnUT8vISHU71yMwG5f47NYAhcTMbsETJhIRu9FxdVm-9ernw0OJai3ZoRspdt-pwWs4mX3HRZVDQfESTlTxep4PWNN7yT47YD_FFfynU9y3i7sN9_KGfxw7BYodHLdKGsYCKEsF1949xUQAa2iLvspzise4X7kUgaK5DfuYMWr3Jfj-D7mZ65rwqrdRNOAZ_cGaFlQ7zAMa7_bVg8JCYXZ2UYj3rx6WEEXc3TjUmepOwVvTqwx_c9PHdSeHdkoH7Bk6kL8gP2paGRPzhYktcIywaUwKmZHps3efehR0wqy3Ttt4N2te1QOaVofUrLXe-ftHbW4-8hb_InM0UDkNvZqAC-HdcLlDMhl6yDSL_-PCH_UZCun98rOzKGs6NCJBtOV54SmoOFGGqU6YevWyw3XGetRMv8Bn3fm0q09DB81m-Sjfer5SXo3tSav9RxmkM0ktS0ZhmNDbjTaMymJSHIALkUzzReVg82l2lfPjn9tgPIN3fgN3brDqcZ4SUzc9RW5Xwebp4FtL_xTn0hsdeACseaJKGHula3KX87m0mb8M4d51YhYihyIyprYsmzkTlk8kKpldxA9MepQQDHxdzY-xO_npTpMdWr6qqY_5Dah_ATxy0lqnlfTZFA2UiYlFcTrryGG92w6X0Bj9i-YVFOkh7oSSsh2k93RVPQ7FgmHt7HweQhwdRDu9-1OqrYGEbFjcapfyksPp37nNRlQzaW7-dK0J1ezxuvJ7OowmP5FoJljvgTFxnt7blDprRbdTCXu5mPSzpYJXUSqcbGS7F--rV7stBQKg" nonce="3ed4bc7600aae7b371fec81c01c04da6" charset="UTF-8"></script><style>
<style>

body{
            background-color: black;
            color: white;
            margin: 0px;
            padding: 0px;
            /* display: none; */
        }

        /* @media (min-width: 300px){
            .test{
                display: block;
            }
        } */

header::before{
            background: url(https://images.unsplash.com/photo-1558976828-9ed9a0c8f4c6?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=2000&fit=max&ixid=eyJhcHBfaWQiOjExNzczfQ);
            /* without position absolute it wont work z index */
            position: absolute;
            content: "";
            /* when the position is done absolute the top and left should be done 0 to cover spaces */
            top: 0;
            left: 0;
            width: 100%; 
            height: 100%;
            /* Without z-index it won't appear text */
            z-index: -1;
            /* In order to make image light */
            opacity: 0.5;
            animation-name: aruku11;
            animation-duration: 3s;
            animation-iteration-count: 1;
          }
          section{
            display: flex;
            flex-direction: column;
            margin: 3px 24px;
            align-items: center;
            height: 344px;
            /* border: 2px solid red; */
            justify-content: center;
            font-size: 2rem;
            
        }

        section > p{
            font-size: 20px;
        }
/*table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
*/




img { display: block; margin: 0 auto; }

.btn{
            
            background-color: yellow ;
            color: black ;
            padding: 6px;
            text-decoration: none;
            border: none;
            font-size: large;
            cursor: pointer;
            margin: 1px;
            border-radius: 4px;
            align : center;
            
           
        }

        .btn:hover{
            background-color: black;
            color : white;
        }

        button {
    display:inline-block; //Typically a button wouldn't need its own line        
    margin:0 auto;
    width: 200px; //or whatever
}
.textstyle{
            font-size: 20px;
            background-color: black;
            color: white;

        }
th {
background-color: #588c7e;
color: white;
}


@keyframes aruku11{
              from{
                  background: url(https://images.unsplash.com/photo-1558976828-9ed9a0c8f4c6?ixlib=rb-1.2.1&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=2000&fit=max&ixid=eyJhcHBfaWQiOjExNzczfQ);
                  width: 0%;
              }
              to{
                  width: 100%;
              }
          }
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<header class="test">
<table>
<tr>
<th>Hotel name</th>
<th>description</th>
<th>accomodation</th>

</tr>

<?php
$conn = mysqli_connect("localhost:3307", "root", "", "tourism_db");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT hname,description,accomodation FROM hotel where pid=1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["hname"]. "</td><td>" . $row["description"] . "</td><td>"
. $row["accomodation"]. "</td></tr>";
 
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>
</table>






<div class="container">
  <div class="vertical-center">
      <a href="../contactus.html" button class="btn ">Any Queries</button> </a>
     
  </div>
</div>
</header>
</body>
</html>