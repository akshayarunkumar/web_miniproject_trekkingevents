function myFunction(){
    para.style.display = 'none';
   
}
function toggleHide(){
    // let btn = document.getElementById('btn');
    let para = document.getElementById('para');
    if(para.style.display != 'none'){
    para.style.display = 'none';
    // This code is written to change inner line of button
    document.getElementById('btn1').innerHTML = "Show Details";
    }
    else{
        para.style.display = 'block';
         // This code is written to change inner line of button
        document.getElementById('btn1').innerHTML = "Hide Details";
    }
}

// let para = document.getElementById('para');
// para.addEventListener('mouseout', function run(){
//     alert('Dont take out of para');
// });

