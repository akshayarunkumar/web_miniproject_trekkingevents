<?php
$servername='localhost:3307';
$username='root';
$password='';
$dbname = "trekking_db";
try {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $text = $_POST['text'];
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    /* set the PDO error mode to exception */
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   $sql = "INSERT INTO feedback (name,email,text)
    VALUES ('$name', '$email','$text')";
    $conn->exec($sql);
    echo "Query has been recorded";
    }
catch(PDOException $e)
    {

    	echo $sql . "<br>" . $e->getMessage();
    }

$conn = null;
?>